import 'package:flutter/material.dart';

class LandingScreen extends StatelessWidget {
  const LandingScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Welcome to Blueprint")),
      body: const Center(
        child: Text("Landing Page", style: TextStyle(fontSize: 24)),
      ),
    );
  }
}
