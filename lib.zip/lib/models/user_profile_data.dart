class UserProfileData {
  String name;
  String email;
  String phone;
  String address;

  UserProfileData({
    required this.name,
    required this.email,
    required this.phone,
    required this.address,
  });
}
